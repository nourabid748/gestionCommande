﻿using MODEL2;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLLER2
{
    public class CommandeADO
    {
        public List<Commande> Listecmd = new List<Commande>();
        // Vos méthodes existantes pour ajouter, supprimer, etc.
        public void Listercommande()
        {
            ClientADO clientADO= new ClientADO();
            clientADO.Listerclient();
            ArticleADO articleADO= new ArticleADO();
            articleADO.Listerarticle();
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlDataReader reader = CNX.Rdd("SELECT * FROM Commande");
            while (reader.Read())
            {
                Commande cmd = new Commande();

                cmd.CodeCmd = (int)reader["CodeCmd"];
                
                cmd.CodeCl = (Client)clientADO.getClById((int)reader["CodeCl"]);
                cmd.Date = (DateTime)reader["Date"];
                cmd.AdresseLiv = (string)reader["AdresseLiv"];

                Listecmd.Add(cmd);
            }
            reader.Close();
            CNX.Deconnecter();
        }
        public void SaveCommande(Commande cmd)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            SqlParameter p_code_Commande = new SqlParameter("@CodeCmd", SqlDbType.Int);
            SqlParameter p_code_client = new SqlParameter("@CodeCl", SqlDbType.Int);
            SqlParameter p_date_Commande = new SqlParameter("@Date", SqlDbType.Date);
            SqlParameter p_adresse_livraison = new SqlParameter("@AdresseLiv", SqlDbType.VarChar);

            requete.CommandText = "INSERT INTO Commande( CodeCmd, CodeCl, Date, AdresseLiv) VALUES(@CodeCmd, @CodeCl, @Date, @AdresseLiv)";
            requete.CommandType = CommandType.Text;

            p_code_Commande.Value = cmd.CodeCmd;
            p_code_client.Value = cmd.CodeCl;
            p_date_Commande.Value = cmd.Date;
            p_adresse_livraison.Value = cmd.AdresseLiv;

            requete.Parameters.Add(p_code_Commande);
            requete.Parameters.Add(p_code_client);
            requete.Parameters.Add(p_date_Commande);
            requete.Parameters.Add(p_adresse_livraison);

            CNX.ExecuteCommand(requete);
            CNX.Deconnecter();

        }
        public Commande getCmdById(int code)
        {
            foreach (Commande commande in Listecmd)
            {
                if (commande.CodeCmd == code) return commande;
            }
            return null;
        }

    }
}

﻿using MODEL2;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLLER2
{
    public class CategorieADO
    {
        
        public List<Categorie> Listecat = new List<Categorie>();
        // Vos méthodes existantes pour ajouter, supprimer, etc.
        public void Listercategorie()
        {
          
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlDataReader reader = CNX.Rdd("SELECT * FROM Categorie");
            while (reader.Read())
            {
                Categorie cat = new Categorie();

                cat.CodeCat = (int)reader["CodeCat"];
                cat.DesCat = (string)reader["DesCat"];


                Listecat.Add(cat);
            }
            reader.Close();
            CNX.Deconnecter();
        }
        public Categorie getCatById(int code)
        {
            foreach (Categorie cat in Listecat)
            {
                if (cat.CodeCat == code) return cat;    
            }
            return null;
        }
        public void SaveCategorie(Categorie cat)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            SqlParameter p_code_cat = new SqlParameter("@CodeCat", SqlDbType.Int);
            SqlParameter p_des_cat = new SqlParameter("@DesCat", SqlDbType.VarChar);

            requete.CommandText = "INSERT INTO Categorie(DesCat) VALUES(@DesCat)";
            requete.CommandType = CommandType.Text;

            p_des_cat.Value = cat.DesCat;

            requete.Parameters.Add(p_des_cat);

            CNX.ExecuteCommand(requete);
            CNX.Deconnecter();

        }
        public void UpdateCategorie(Categorie cat)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            requete.CommandText = "UPDATE Categorie SET DesCat = @DesCat WHERE CodeCat = @CodeCat";
            requete.CommandType = CommandType.Text;

            requete.Parameters.AddWithValue("@CodeCat", cat.CodeCat);
            requete.Parameters.AddWithValue("@DesCat", cat.DesCat);
            


            CNX.ExecuteCommand(requete);
            Console.WriteLine("MAJ effectué avec succès");
            Console.Out.Flush();
            CNX.Deconnecter();
        }
        public void DeleteCategorie(Categorie cat)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlConnection maConnexionSQL = Connexion.conn; // Obtenez la connexion à partir de l'instance CNX
            SqlCommand requete = new SqlCommand();
            requete.Connection = maConnexionSQL; // Utilisez la connexion obtenue
            requete.CommandText = "DELETE FROM Categorie WHERE CodeCat = @CodeCat";
            requete.CommandType = CommandType.Text;

            // Ajoutez le paramètre @clientId
            requete.Parameters.AddWithValue("@CodeCat", cat.CodeCat);

            requete.ExecuteNonQuery(); // Exécutez la requête
            Console.WriteLine("suppression effectué avec succès");
            CNX.Deconnecter();
        }
    }
}

﻿using MODEL2;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLLER2
{
    public class ArticleADO

    {
        
        public List<Article> Listeart = new List<Article>();
        // Vos méthodes existantes pour ajouter, supprimer, etc.
        public void Listerarticle()
        {
            CategorieADO categorieADO = new CategorieADO();
            categorieADO.Listercategorie();
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlDataReader reader = CNX.Rdd("SELECT * FROM Article");
            while (reader.Read())
            {
                Article art = new Article();

                art.CodeArt = (int)reader["CodeArt"];
                art.DesArt = (string)reader["DesArt"];
                art.PU = (string)reader["PU"];
                art.CodeCat = (Categorie)categorieADO.getCatById((int)reader["CodeCat"]);
                

                Listeart.Add(art);
            }
            reader.Close();
            CNX.Deconnecter();
        }
        public void SaveArticle(Article art)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            SqlParameter p_des_article = new SqlParameter("@DesArt", SqlDbType.VarChar);
            SqlParameter p_prix_unitaire = new SqlParameter("@PU", SqlDbType.VarChar);
            SqlParameter p_code_categorie = new SqlParameter("@CodeCat", SqlDbType.Int);

            requete.CommandText = "INSERT INTO Article(DesArt, PU, CodeCat) VALUES(@DesArt, @PU, @CodeCat)";
            requete.CommandType = CommandType.Text;

            p_des_article.Value = art.DesArt;
            p_prix_unitaire.Value = art.PU;
            p_code_categorie.Value = art.CodeCat;

            requete.Parameters.Add(p_des_article);
            requete.Parameters.Add(p_prix_unitaire);
            requete.Parameters.Add(p_code_categorie);

            CNX.ExecuteCommand(requete);
            Console.WriteLine("Article ajouté avec succès");
            CNX.Deconnecter();

        }
        public void UpdateArticle(Article art)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            requete.CommandText = "UPDATE Article SET DesArt = @DesArt, PU = @PU, CodeCat = @CodeCat WHERE CodeArt = @CodeArt";
            requete.CommandType = CommandType.Text;

            requete.Parameters.AddWithValue("@CodeArt", art.CodeArt);
            requete.Parameters.AddWithValue("@DesArt", art.DesArt);
            requete.Parameters.AddWithValue("@PU", art.PU);
            requete.Parameters.AddWithValue("@CodeCat", art.CodeArt);
            


            CNX.ExecuteCommand(requete);
            Console.WriteLine("MAJ effectué avec succès");
            Console.Out.Flush();
            CNX.Deconnecter();
        }
        public void DeleteArticle(Article art)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlConnection maConnexionSQL = Connexion.conn; // Obtenez la connexion à partir de l'instance CNX
            SqlCommand requete = new SqlCommand();
            requete.Connection = maConnexionSQL; // Utilisez la connexion obtenue
            requete.CommandText = "DELETE FROM Article WHERE CodeArt = @CodeArt";
            requete.CommandType = CommandType.Text;

            // Ajoutez le paramètre @clientId
            requete.Parameters.AddWithValue("@CodeArt", art.CodeArt);

            requete.ExecuteNonQuery(); // Exécutez la requête
            Console.WriteLine("suppression effectué avec succès");
            CNX.Deconnecter();
        }
        public Article getArtById(int code)
        {
            foreach (Article article in Listeart)
            {
                if (article.CodeArt == code) return article;
            }
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MODEL2;

namespace CONTROLLER2
{
    public class ClientADO
    {

        public List<Client> Listeclt = new List<Client>();
        // Vos méthodes existantes pour ajouter, supprimer, etc.
        public void Listerclient()
        {
            
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlDataReader reader = CNX.Rdd("SELECT * FROM Client");
            while (reader.Read())
            {
                Client clie = new Client();

                clie.CodeCl = (int)reader["CodeCl"];
                clie.Nom = (string)reader["Nom"];
                clie.Prenom = (string)reader["Prenom"];
                clie.Adresse = (string)reader["Adresse"];
                clie.Tel = (int)reader["Tel"];
                clie.Email = (string)reader["Email"];

                Listeclt.Add(clie);
            }
            reader.Close();
            CNX.Deconnecter();
        }
        public void SaveClient(Client client)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            SqlParameter p_code_client = new SqlParameter("@CodeCl", SqlDbType.Int);
            SqlParameter p_nom_client = new SqlParameter("@Nom", SqlDbType.VarChar);
            SqlParameter p_prenom_client = new SqlParameter("@Prenom", SqlDbType.VarChar);
            SqlParameter p_adresse_client = new SqlParameter("@Adresse", SqlDbType.VarChar);
            SqlParameter p_telephone_client = new SqlParameter("@Tel", SqlDbType.Int);
            SqlParameter p_email_client = new SqlParameter("@Email", SqlDbType.VarChar);

            requete.CommandText = "INSERT INTO Client(Nom, Prenom, Adresse, Tel, Email) VALUES(@Nom, @Prenom, @Adresse, @Tel, @Email)";
            requete.CommandType = CommandType.Text;

            p_nom_client.Value = client.Nom;
            p_prenom_client.Value = client.Prenom;
            p_adresse_client.Value = client.Adresse;
            p_telephone_client.Value = client.Tel;
            p_email_client.Value = client.Email;

            requete.Parameters.Add(p_nom_client);
            requete.Parameters.Add(p_prenom_client);
            requete.Parameters.Add(p_adresse_client);
            requete.Parameters.Add(p_telephone_client);
            requete.Parameters.Add(p_email_client);

            CNX.ExecuteCommand(requete);
            Console.WriteLine("Client ajouté avec succès");
            CNX.Deconnecter();

        }
        private string TruncateString(string value, int maxLength)
        {
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        public void UpdateClient(Client client)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand();

            requete.CommandText = "UPDATE Client SET Nom = @Nom, Prenom = @Prenom, Adresse = @Adresse, Tel = @Tel, Email = @Email WHERE CodeCl = @CodeCl";
            requete.CommandType = CommandType.Text;

            requete.Parameters.AddWithValue("@CodeCl", client.CodeCl);
            requete.Parameters.AddWithValue("@Nom", TruncateString(client.Nom, 50));
            requete.Parameters.AddWithValue("@Prenom", TruncateString(client.Prenom, 50));
            requete.Parameters.AddWithValue("@Adresse", TruncateString(client.Adresse, 100));
            requete.Parameters.AddWithValue("@Tel", client.Tel);
            requete.Parameters.AddWithValue("@Email", TruncateString(client.Email, 50));
         

            CNX.ExecuteCommand(requete);
            Console.WriteLine("MAJ effectué avec succès");
            Console.Out.Flush();
            CNX.Deconnecter();
        }


        public void DeleteClient(Client client)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlConnection maConnexionSQL = Connexion.conn; // Obtenez la connexion à partir de l'instance CNX
            SqlCommand requete = new SqlCommand();
            requete.Connection = maConnexionSQL; // Utilisez la connexion obtenue
            requete.CommandText = "DELETE FROM Client WHERE CodeCl = @CodeCl";
            requete.CommandType = CommandType.Text;

            // Ajoutez le paramètre @clientId
            requete.Parameters.AddWithValue("@CodeCl", client.CodeCl);

            requete.ExecuteNonQuery(); // Exécutez la requête
            Console.WriteLine("suppression effectué avec succès");
            CNX.Deconnecter();
        }
        public Client getClById(int code)
        {
            foreach (Client client in Listeclt)
            {
                if (client.CodeCl == code) return client;
            }
            return null;
        }

    }
}

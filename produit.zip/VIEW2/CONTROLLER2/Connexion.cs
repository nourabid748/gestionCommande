﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLLER2
{
    public class Connexion
    {
        public static SqlConnection conn = new SqlConnection("database=Gestioncommande;server=NOUR-ABID;User ID=sa;pwd=pass");

        public void Connecter()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();

            }
        }

        public bool ExecuteCommand(SqlCommand cmd)
        {
            cmd.Connection = conn;
            // Add parameter to the SqlCommand
            
            if (cmd.ExecuteNonQuery() >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public SqlDataReader Rdd(string value)
        {
            SqlCommand command = new SqlCommand(value, conn);
            SqlDataReader reader = command.ExecuteReader();
            return reader;
        }
        public void Deconnecter()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();

            }
        }
    }
}

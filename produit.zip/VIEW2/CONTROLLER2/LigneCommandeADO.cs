﻿using MODEL2;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONTROLLER2
{
    public class LigneCommandeADO
    {
        
        public List<LigneCommande> liste = new List<LigneCommande>();
        

        

        public void ListerLc()
        {
            ArticleADO articleADO = new ArticleADO();
            CommandeADO commandeADO = new CommandeADO();
            articleADO.Listerarticle();
            commandeADO.Listercommande();


            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlDataReader reader = CNX.Rdd("SELECT * FROM LigneCommande");
            
           
            while (reader.Read())
            {

                LigneCommande lc = new LigneCommande();
                lc.CodeArt = (Article)articleADO.getArtById((int)reader["CodeArt"]);
                    lc.CodeCmd = (Commande)commandeADO.getCmdById((int)reader["CodeCmd"]);
                    lc.Quantite = (int)reader["Quantite"];




                    liste.Add(lc);
                }
                reader.Close();
                CNX.Deconnecter();
                
            

        }
        public void save_ligneCommande(LigneCommande lc)
        {
            Connexion CNX = new Connexion();
            CNX.Connecter();
            SqlCommand requete = new SqlCommand("INSERT INTO ligneCommande ( CodeArt, CodeCmd , Quantite) VALUES ( @CodeArt,@CodeCmd,@Quantite)");


            requete.Parameters.AddWithValue("@CodeArt", lc.CodeArt);
            requete.Parameters.AddWithValue("@CodeCmd", lc.CodeCmd);
            requete.Parameters.AddWithValue("@Quantite", lc.Quantite);
            CNX.ExecuteCommand(requete);
            Console.WriteLine("Ligne Commande ajoutée avec succès");
            CNX.Deconnecter();
        }
        






    }
}

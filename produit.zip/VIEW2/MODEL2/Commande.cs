﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL2
{
    public class Commande
    {
        public int CodeCmd;
        public DateTime Date;
        public string AdresseLiv;
        public Client CodeCl;

        public Commande()
        {
        }

        public Commande(int numCom, DateTime date, string adresseLiv, Client code_Client)
        {
            CodeCmd = numCom;
            Date = date;
            AdresseLiv = adresseLiv;
            CodeCl = code_Client;
        }

        public int NumCom { get => CodeCmd; set => CodeCmd = value; }
        public DateTime DateCom { get => Date; set => Date = value; }
        public string AdresseLivraison { get => AdresseLiv; set => AdresseLiv = value; }
        public Client CodeClient { get => CodeCl; set => CodeCl = value; }

        public override string ToString()
        {
            return CodeCmd.ToString();
        }
    }
}

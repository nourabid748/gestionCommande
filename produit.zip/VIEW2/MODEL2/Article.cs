﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL2
{
    public class Article
    {
        public int CodeArt;
        public string DesArt;
        public string PU;
        public Categorie CodeCat;

        public Article()
        {
        }

        public Article(int codeArticle, string desigArticle, string prixUnitaire, Categorie code_Categ)
        {
            CodeArt = codeArticle;
            DesArt = desigArticle;
            PU = prixUnitaire;
            CodeCat = code_Categ;
        }

        public int CodeArticle { get => CodeArt; set => CodeArt = value; }
        public string DesigArticle { get => DesArt; set => DesArt = value; }
        public string PrixUnitaire { get => PU; set => PU = value; }
        public Categorie CodeCateg { get => CodeCat; set => CodeCat = value; }
        public override string ToString()
        {
            return CodeArt.ToString();
        }
    }
}

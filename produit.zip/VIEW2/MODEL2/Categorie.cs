﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL2
{
    public class Categorie
    {
        public int CodeCat;
        public string DesCat;

        public Categorie()
        {
        }

        public Categorie(int codeCateg, string designCateg)
        {
            CodeCat = codeCateg;
            DesCat = designCateg;
        }

        public int CodeCateg { get => CodeCat; set => CodeCat = value; }
        public string DesignCateg { get => DesCat; set => DesCat = value; }
        public override string ToString()
        {
            return CodeCat.ToString();
        }
    }
   
}

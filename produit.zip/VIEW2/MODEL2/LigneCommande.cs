﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL2
{
    public class LigneCommande
    {
        public Article CodeArt;
        public Commande CodeCmd;
        public int Quantite;

        public LigneCommande()
        {
        }

        public LigneCommande(Article code_Article, Commande num_Com, int quantite)
        {
            CodeArt = code_Article;
            CodeCmd = num_Com;
            Quantite = quantite;
        }

        public Article CodeArticle { get => CodeArt; set => CodeArt = value; }
        public Commande NumCom { get => CodeCmd; set => CodeCmd = value; }
        public int QuantiteCmd { get => Quantite; set => Quantite = value; }

        
    }
}

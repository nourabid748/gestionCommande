﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL2
{
    public class Client
    {
        public int CodeCl;
        public string Nom;
        public string Prenom;
        public string Adresse;
        public int Tel;
        public string Email;

        public Client()
        {
        }

        public Client(int CodeCl, string Nom, string Prenom, string Adresse, int Tel, string Email)
        {
            this.CodeCl = CodeCl;
            this.Nom = Nom;
            this.Prenom = Prenom;
            this.Adresse = Adresse;
            this.Tel = Tel;
            this.Email = Email;
        }

        public int CodeClient { get => CodeCl; set => CodeCl = value; }
        public string NomClient { get => Nom; set => Nom = value; }
        public string PrenomClient { get => Prenom; set => Prenom = value; }
        public string AdresseClient { get => Adresse; set => Adresse = value; }
        public int TelephoneClient { get => Tel; set => Tel = value; }
        public string EmailClient { get => Email; set => Email = value; }

        public override string ToString()
        {
            return CodeCl.ToString();
        }
    }
}

﻿namespace VIEW2
{
    partial class Commande
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label adresseLivraisonLabel;
            System.Windows.Forms.Label dateComLabel;
            System.Windows.Forms.Label numComLabel;
            System.Windows.Forms.Label adresseClientLabel;
            System.Windows.Forms.Label codeClientLabel;
            System.Windows.Forms.Label quantiteCmdLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Commande));
            this.button2 = new System.Windows.Forms.Button();
            this.commandeBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.commandeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.commandeBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.adresseLivraisonTextBox = new System.Windows.Forms.TextBox();
            this.dateComDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.numComTextBox = new System.Windows.Forms.TextBox();
            this.ligneCommandeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.quantiteCmdNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.articleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.articleComboBox = new System.Windows.Forms.ComboBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientComboBox = new System.Windows.Forms.ComboBox();
            this.commandeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ligneCommandeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            adresseLivraisonLabel = new System.Windows.Forms.Label();
            dateComLabel = new System.Windows.Forms.Label();
            numComLabel = new System.Windows.Forms.Label();
            adresseClientLabel = new System.Windows.Forms.Label();
            codeClientLabel = new System.Windows.Forms.Label();
            quantiteCmdLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingNavigator)).BeginInit();
            this.commandeBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ligneCommandeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantiteCmdNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandeDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ligneCommandeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // adresseLivraisonLabel
            // 
            adresseLivraisonLabel.AutoSize = true;
            adresseLivraisonLabel.Location = new System.Drawing.Point(12, 37);
            adresseLivraisonLabel.Name = "adresseLivraisonLabel";
            adresseLivraisonLabel.Size = new System.Drawing.Size(118, 16);
            adresseLivraisonLabel.TabIndex = 6;
            adresseLivraisonLabel.Text = "Adresse Livraison:";
            // 
            // dateComLabel
            // 
            dateComLabel.AutoSize = true;
            dateComLabel.Location = new System.Drawing.Point(12, 66);
            dateComLabel.Name = "dateComLabel";
            dateComLabel.Size = new System.Drawing.Size(70, 16);
            dateComLabel.TabIndex = 8;
            dateComLabel.Text = "Date Com:";
            // 
            // numComLabel
            // 
            numComLabel.AutoSize = true;
            numComLabel.Location = new System.Drawing.Point(12, 93);
            numComLabel.Name = "numComLabel";
            numComLabel.Size = new System.Drawing.Size(69, 16);
            numComLabel.TabIndex = 10;
            numComLabel.Text = "Num Com:";
            // 
            // adresseClientLabel
            // 
            adresseClientLabel.AutoSize = true;
            adresseClientLabel.Location = new System.Drawing.Point(12, 155);
            adresseClientLabel.Name = "adresseClientLabel";
            adresseClientLabel.Size = new System.Drawing.Size(40, 16);
            adresseClientLabel.TabIndex = 12;
            adresseClientLabel.Text = "Client";
            // 
            // codeClientLabel
            // 
            codeClientLabel.AutoSize = true;
            codeClientLabel.Location = new System.Drawing.Point(8, 202);
            codeClientLabel.Name = "codeClientLabel";
            codeClientLabel.Size = new System.Drawing.Size(44, 16);
            codeClientLabel.TabIndex = 14;
            codeClientLabel.Text = "Article";
            // 
            // quantiteCmdLabel
            // 
            quantiteCmdLabel.AutoSize = true;
            quantiteCmdLabel.Location = new System.Drawing.Point(3, 291);
            quantiteCmdLabel.Name = "quantiteCmdLabel";
            quantiteCmdLabel.Size = new System.Drawing.Size(90, 16);
            quantiteCmdLabel.TabIndex = 24;
            quantiteCmdLabel.Text = "Quantite Cmd:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(449, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 49);
            this.button2.TabIndex = 1;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // commandeBindingNavigator
            // 
            this.commandeBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.commandeBindingNavigator.BindingSource = this.commandeBindingSource;
            this.commandeBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.commandeBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.commandeBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.commandeBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.commandeBindingNavigatorSaveItem});
            this.commandeBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.commandeBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.commandeBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.commandeBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.commandeBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.commandeBindingNavigator.Name = "commandeBindingNavigator";
            this.commandeBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.commandeBindingNavigator.Size = new System.Drawing.Size(702, 27);
            this.commandeBindingNavigator.TabIndex = 4;
            this.commandeBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // commandeBindingSource
            // 
            this.commandeBindingSource.DataSource = typeof(MODEL2.Commande);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // commandeBindingNavigatorSaveItem
            // 
            this.commandeBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.commandeBindingNavigatorSaveItem.Enabled = false;
            this.commandeBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("commandeBindingNavigatorSaveItem.Image")));
            this.commandeBindingNavigatorSaveItem.Name = "commandeBindingNavigatorSaveItem";
            this.commandeBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.commandeBindingNavigatorSaveItem.Text = "Enregistrer les données";
            // 
            // adresseLivraisonTextBox
            // 
            this.adresseLivraisonTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.commandeBindingSource, "AdresseLivraison", true));
            this.adresseLivraisonTextBox.Location = new System.Drawing.Point(136, 34);
            this.adresseLivraisonTextBox.Name = "adresseLivraisonTextBox";
            this.adresseLivraisonTextBox.Size = new System.Drawing.Size(200, 22);
            this.adresseLivraisonTextBox.TabIndex = 7;
            // 
            // dateComDateTimePicker
            // 
            this.dateComDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.commandeBindingSource, "DateCom", true));
            this.dateComDateTimePicker.Location = new System.Drawing.Point(136, 62);
            this.dateComDateTimePicker.Name = "dateComDateTimePicker";
            this.dateComDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.dateComDateTimePicker.TabIndex = 9;
            // 
            // numComTextBox
            // 
            this.numComTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.commandeBindingSource, "NumCom", true));
            this.numComTextBox.Location = new System.Drawing.Point(136, 90);
            this.numComTextBox.Name = "numComTextBox";
            this.numComTextBox.Size = new System.Drawing.Size(200, 22);
            this.numComTextBox.TabIndex = 11;
            // 
            // ligneCommandeBindingSource
            // 
            this.ligneCommandeBindingSource.DataSource = typeof(MODEL2.LigneCommande);
            // 
            // quantiteCmdNumericUpDown
            // 
            this.quantiteCmdNumericUpDown.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ligneCommandeBindingSource, "QuantiteCmd", true));
            this.quantiteCmdNumericUpDown.Location = new System.Drawing.Point(99, 289);
            this.quantiteCmdNumericUpDown.Name = "quantiteCmdNumericUpDown";
            this.quantiteCmdNumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.quantiteCmdNumericUpDown.TabIndex = 25;
            this.quantiteCmdNumericUpDown.ValueChanged += new System.EventHandler(this.quantiteCmdNumericUpDown_ValueChanged);
            // 
            // articleBindingSource
            // 
            this.articleBindingSource.DataSource = typeof(MODEL2.Article);
            // 
            // articleComboBox
            // 
            this.articleComboBox.DataSource = this.articleBindingSource;
            this.articleComboBox.DisplayMember = "DesigArticle";
            this.articleComboBox.FormattingEnabled = true;
            this.articleComboBox.Location = new System.Drawing.Point(69, 199);
            this.articleComboBox.Name = "articleComboBox";
            this.articleComboBox.Size = new System.Drawing.Size(300, 24);
            this.articleComboBox.TabIndex = 26;
            this.articleComboBox.ValueMember = "CodeArticle";
            this.articleComboBox.SelectedIndexChanged += new System.EventHandler(this.articleComboBox_SelectedIndexChanged);
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataSource = typeof(MODEL2.Client);
            // 
            // clientComboBox
            // 
            this.clientComboBox.DataSource = this.clientBindingSource;
            this.clientComboBox.DisplayMember = "EmailClient";
            this.clientComboBox.FormattingEnabled = true;
            this.clientComboBox.Location = new System.Drawing.Point(69, 152);
            this.clientComboBox.Name = "clientComboBox";
            this.clientComboBox.Size = new System.Drawing.Size(300, 24);
            this.clientComboBox.TabIndex = 27;
            this.clientComboBox.ValueMember = "AdresseClient";
            this.clientComboBox.SelectedIndexChanged += new System.EventHandler(this.clientComboBox_SelectedIndexChanged);
            // 
            // commandeDataGridView
            // 
            this.commandeDataGridView.AutoGenerateColumns = false;
            this.commandeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.commandeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.commandeDataGridView.DataSource = this.commandeBindingSource;
            this.commandeDataGridView.Location = new System.Drawing.Point(0, 374);
            this.commandeDataGridView.Name = "commandeDataGridView";
            this.commandeDataGridView.RowHeadersWidth = 51;
            this.commandeDataGridView.RowTemplate.Height = 24;
            this.commandeDataGridView.Size = new System.Drawing.Size(551, 99);
            this.commandeDataGridView.TabIndex = 27;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NumCom";
            this.dataGridViewTextBoxColumn1.HeaderText = "NumCom";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DateCom";
            this.dataGridViewTextBoxColumn2.HeaderText = "DateCom";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "AdresseLivraison";
            this.dataGridViewTextBoxColumn3.HeaderText = "AdresseLivraison";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CodeClient";
            this.dataGridViewTextBoxColumn4.HeaderText = "CodeClient";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // ligneCommandeDataGridView
            // 
            this.ligneCommandeDataGridView.AutoGenerateColumns = false;
            this.ligneCommandeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ligneCommandeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.ligneCommandeDataGridView.DataSource = this.ligneCommandeBindingSource;
            this.ligneCommandeDataGridView.Location = new System.Drawing.Point(0, 501);
            this.ligneCommandeDataGridView.Name = "ligneCommandeDataGridView";
            this.ligneCommandeDataGridView.RowHeadersWidth = 51;
            this.ligneCommandeDataGridView.RowTemplate.Height = 24;
            this.ligneCommandeDataGridView.Size = new System.Drawing.Size(551, 74);
            this.ligneCommandeDataGridView.TabIndex = 27;
            this.ligneCommandeDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ligneCommandeDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "CodeArticle";
            this.dataGridViewTextBoxColumn5.HeaderText = "CodeArticle";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "NumCom";
            this.dataGridViewTextBoxColumn6.HeaderText = "NumCom";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "QuantiteCmd";
            this.dataGridViewTextBoxColumn7.HeaderText = "QuantiteCmd";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 125;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(265, 289);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 28);
            this.button1.TabIndex = 28;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Commande
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 729);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ligneCommandeDataGridView);
            this.Controls.Add(this.commandeDataGridView);
            this.Controls.Add(this.clientComboBox);
            this.Controls.Add(this.articleComboBox);
            this.Controls.Add(quantiteCmdLabel);
            this.Controls.Add(this.quantiteCmdNumericUpDown);
            this.Controls.Add(adresseClientLabel);
            this.Controls.Add(codeClientLabel);
            this.Controls.Add(adresseLivraisonLabel);
            this.Controls.Add(this.adresseLivraisonTextBox);
            this.Controls.Add(dateComLabel);
            this.Controls.Add(this.dateComDateTimePicker);
            this.Controls.Add(numComLabel);
            this.Controls.Add(this.numComTextBox);
            this.Controls.Add(this.commandeBindingNavigator);
            this.Controls.Add(this.button2);
            this.Name = "Commande";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Commande_Load);
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingNavigator)).EndInit();
            this.commandeBindingNavigator.ResumeLayout(false);
            this.commandeBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ligneCommandeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantiteCmdNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandeDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ligneCommandeDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource commandeBindingSource;
        private System.Windows.Forms.BindingNavigator commandeBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton commandeBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox adresseLivraisonTextBox;
        private System.Windows.Forms.DateTimePicker dateComDateTimePicker;
        private System.Windows.Forms.TextBox numComTextBox;
        private System.Windows.Forms.BindingSource ligneCommandeBindingSource;
        private System.Windows.Forms.NumericUpDown quantiteCmdNumericUpDown;
        private System.Windows.Forms.BindingSource articleBindingSource;
        private System.Windows.Forms.ComboBox articleComboBox;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private System.Windows.Forms.ComboBox clientComboBox;
        private System.Windows.Forms.DataGridView commandeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView ligneCommandeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button button1;
    }
}
﻿using CONTROLLER2;
using MODEL2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VIEW2
{
    public partial class Commande : Form
    {   
        private CommandeADO commandeADO=new CommandeADO();
        private ClientADO clientADO=new ClientADO();    
        private ArticleADO articleADO=new ArticleADO();
        private LigneCommandeADO lcADO=new LigneCommandeADO();
        public Commande()
        {
            InitializeComponent();
        }

        private void clientComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void articleComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Commande_Load(object sender, EventArgs e)
        {
            commandeADO.Listercommande();
            commandeBindingSource.DataSource = commandeADO.Listecmd;
            clientADO.Listerclient();
            clientBindingSource.DataSource = clientADO.Listeclt;
            articleADO.Listerarticle();
            articleBindingSource.DataSource = articleADO.Listeart;
            lcADO.ListerLc();
            ligneCommandeBindingSource.DataSource = lcADO.liste;
            

        }

        private void commandeDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void quantiteCmdNumericUpDown_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (commandeBindingSource.Current != null)
            {

                MODEL2.Commande commande = new MODEL2.Commande();
                commande.CodeCl = (MODEL2.Client)clientBindingSource.Current;
         
                commande = (MODEL2.Commande)commandeBindingSource.Current;

                commandeADO.SaveCommande(commande);

                MessageBox.Show("commande enregistré");



            }
            else
            {
                MessageBox.Show("aucune commande selectionné");
            }

        }

        private void ligneCommandeDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            

        }
    }
}

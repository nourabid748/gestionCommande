﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CONTROLLER2;
using MODEL2;
namespace VIEW2
{
    public partial class Client : Form
    {
        private ClientADO clientADO = new ClientADO();
        public Client()
        {
            InitializeComponent();
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ClientADO clientADO = new ClientADO();
            clientADO.Listerclient();
            clientBindingSource.DataSource = clientADO.Listeclt;
        }
        
        

        private void button2_Click(object sender, EventArgs e)
        {
            clientBindingSource.AddNew();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(clientBindingSource.Current!=null)
            {

                MODEL2.Client client = new MODEL2.Client();
                   client= (MODEL2.Client)clientBindingSource.Current;
                
                clientADO.SaveClient(client);

                MessageBox.Show("client enregistré");
                
                    
                
            }
            else
            {
                MessageBox.Show("aucun client selectionné");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MODEL2.Client client=(MODEL2.Client)clientBindingSource.Current;
            clientADO.UpdateClient(client);
            clientDataGridView.Refresh();

        }

    

        private void button3_Click(object sender, EventArgs e)
        {
            MODEL2.Client client = (MODEL2.Client)clientBindingSource.Current;
            clientADO.DeleteClient(client);
            clientBindingSource.Remove(client);
            clientDataGridView.Refresh();

        }

        private void clientDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Article articleForm = new Article();
            articleForm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Categorie categorieForm = new Categorie();
            categorieForm.Show();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Commande commandeForm = new Commande();

            commandeForm.Show();
        }
    }
}

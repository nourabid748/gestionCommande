﻿using CONTROLLER2;
using MODEL2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VIEW2
{
    public partial class Categorie : Form
    {

        public Categorie()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            CategorieADO catad = new CategorieADO();
            catad.Listercategorie();
            categorieBindingSource1.DataSource= catad.Listecat;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            categorieBindingSource1.AddNew();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (categorieBindingSource1.Current != null)
            {
                MODEL2.Categorie categorie=new MODEL2.Categorie();
                categorie=(MODEL2.Categorie)categorieBindingSource1.Current;
                CategorieADO catad = new CategorieADO();
                catad.SaveCategorie(categorie);
                MessageBox.Show("categorie enregistré");
            }
            else
            {
                MessageBox.Show("aucun");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MODEL2.Categorie categorie=(MODEL2.Categorie)categorieBindingSource1.Current;
            CategorieADO catad = new CategorieADO();
            catad.UpdateCategorie(categorie);
            MessageBox.Show("categorie maj");
            categorieDataGridView.Refresh();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MODEL2.Categorie categorie = (MODEL2.Categorie)categorieBindingSource1.Current;
            CategorieADO catad = new CategorieADO();
            catad.DeleteCategorie(categorie);
            MessageBox.Show("categorie supprimé");
            categorieDataGridView.Refresh();

        }

        private void categorieDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿using CONTROLLER2;
using MODEL2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VIEW2
{
    public partial class Article : Form
    {   
        private ArticleADO articleADO= new ArticleADO();
        public Article()
        {
            InitializeComponent();
        }


        private void categorieComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void articleDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            CategorieADO ad = new CategorieADO();
            ad.Listercategorie();
            categorieBindingSource.DataSource = ad.Listecat;
            ArticleADO articleADO = new ArticleADO();
            articleADO.Listerarticle();
            articleBindingSource.DataSource = articleADO.Listeart;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            articleBindingSource.AddNew();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (articleBindingSource.Current != null)
            {

                MODEL2.Article article = new MODEL2.Article();
                article.CodeCat = (MODEL2.Categorie)categorieBindingSource.Current;
                article = (MODEL2.Article)articleBindingSource.Current;

                articleADO.SaveArticle(article);

                MessageBox.Show("article enregistré");



            }
            else
            {
                MessageBox.Show("aucun article selectionné");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MODEL2.Article article = (MODEL2.Article)articleBindingSource.Current;
            articleADO.UpdateArticle(article);
            articleDataGridView.Refresh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MODEL2.Article article = (MODEL2.Article)articleBindingSource.Current;
            articleADO.DeleteArticle(article);
            articleBindingSource.Remove(article);
            articleDataGridView.Refresh();
        }
    }
}
